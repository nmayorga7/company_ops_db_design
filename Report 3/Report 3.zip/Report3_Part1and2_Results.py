Python 3.13.0 (tags/v3.13.0:60403a5, Oct  7 2024, 09:38:07) [MSC v.1941 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
==== RESTART: C:/Users/natas/AppData/Local/Programs/Python/Python313/test.py ===
Query 1 Results:
Client Name: Bright Enterprises, Project Start Date: 2010-05-15

Query 2 Results:
Employee ID: 2, Name: David Leary
Employee ID: 4, Name: Jake Thompson
Employee ID: 7, Name: Sophia Chavis
Employee ID: 16, Name: Lucas Rivera

Query 3 Results:
Employee Name: Aditi Kapoor, Project ID: 2, Total Hours: 8
Employee Name: Aditi Kapoor, Project ID: 3, Total Hours: 7
Employee Name: Aditi Kapoor, Project ID: 4, Total Hours: 7
Employee Name: Aditi Kapoor, Project ID: 5, Total Hours: 9

Query 4 Results:
Employee Name: Maria Hernandez
Employee Name: David Leary
Employee Name: Aditi Kapoor
Employee Name: Jake Thompson
Employee Name: Emily Patel
Employee Name: Liam Davis
Employee Name: Sophia Chavis

Query 5 Results:
Employee ID: 1, Name: Maria Hernandez
Employee ID: 3, Name: Aditi Kapoor
Employee ID: 4, Name: Jake Thompson
Employee ID: 5, Name: Emily Patel
Employee ID: 6, Name: Liam Davis
Employee ID: 7, Name: Sophia Chavis

Total hours for project ID 7: 34

Total hours worked by employee ID 6 on project ID 3: 9
